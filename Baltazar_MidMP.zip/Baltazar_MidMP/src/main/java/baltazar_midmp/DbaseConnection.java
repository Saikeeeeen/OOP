/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baltazar_midmp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbaseConnection {
    
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/furniture?zeroDateTimeBehavior=CONVERT_TO_NULL";
        String username = "root";
        String password = "root"; // Replace with your XAMPP MySQL password

        Connection connection = DriverManager.getConnection(url, username, password);
        return connection;
    }
}


