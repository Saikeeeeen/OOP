/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baltazar_midmp;

/**
 *
 * @author jbalt
 */
public interface manage {
    
    void authorize();
}
